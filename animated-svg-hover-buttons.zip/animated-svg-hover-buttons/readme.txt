This template / effect / code has been created by Tyler Peterson.
You can customize and check it out on its original site on the following link:
https://codepen.io/Gingernaut/pen/qOgMLy

Thank you